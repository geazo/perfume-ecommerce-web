<?php require_once("../template/heading.php")?>
<!-- code here -->

<?php require_once("../template/footing.php")?>